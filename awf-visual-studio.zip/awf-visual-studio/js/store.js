/* ============================================================
   AWF Visual Studio - Camada de Dados (Store)
   ------------------------------------------------------------
   Persistência local no navegador:
   - localStorage: configurações do site, serviços, credenciais (hash)
   - IndexedDB   : projetos do portfólio + imagens (base64) e mensagens
   Isso permite que o site funcione 100% no navegador, sem servidor.
   Para produção com múltiplos administradores, veja o LEIA-ME.txt
   ============================================================ */
(function (global) {
  'use strict';

  var DB_NAME = 'awf_visual_studio';
  var DB_VERSION = 1;
  var LS_CONFIG = 'awf_config';
  var LS_AUTH = 'awf_auth';       // hash da senha (setup do 1º acesso)
  var LS_SESSION = 'awf_session'; // sessão ativa

  var WHATSAPP_NUMBER = '5564992355772';

  /* ---------- Placeholders (SVG) ---------- */
  function svg(txt, sub, w, h) {
    var s = '<svg xmlns="http://www.w3.org/2000/svg" width="' + w + '" height="' + h + '" viewBox="0 0 ' + w + ' ' + h + '">' +
      '<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">' +
      '<stop offset="0" stop-color="#1c1c1c"/><stop offset="1" stop-color="#0a0a0a"/></linearGradient></defs>' +
      '<rect width="' + w + '" height="' + h + '" fill="url(#g)"/>' +
      '<rect x="14" y="14" width="' + (w - 28) + '" height="' + (h - 28) + '" fill="none" stroke="#e10600" stroke-opacity="0.35" stroke-width="2"/>' +
      '<text x="50%" y="48%" fill="#e10600" font-family="Poppins,sans-serif" font-size="' + Math.round(h / 7) + '" font-weight="800" text-anchor="middle">' + txt + '</text>' +
      (sub ? '<text x="50%" y="62%" fill="#8a8a8a" font-family="Inter,sans-serif" font-size="' + Math.round(h / 20) + '" text-anchor="middle">' + sub + '</text>' : '') +
      '</svg>';
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(s);
  }

  var LOGO_DEFAULT = 'data:image/svg+xml;utf8,' + encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" rx="14" fill="#0a0a0a"/>' +
    '<text x="50" y="60" font-size="40" font-family="Poppins,sans-serif" font-weight="800" text-anchor="middle" fill="#fff">A<tspan fill="#e10600">W</tspan>F</text>' +
    '<rect x="26" y="70" width="48" height="4" fill="#e10600"/></svg>');

  var PHOTO_DEFAULT = svg('Sua Foto', 'Envie no painel administrativo', 400, 500);

  var CATEGORIES = ['Redes Sociais', 'Flyers', 'Fachadas', 'Placas', 'Plotagem de Veículos', 'Logotipos', 'Comunicação Visual', 'Outros'];

  var DEFAULT_SERVICES = [
    { id: 's1', icon: 'social', title: 'Design para Redes Sociais', desc: 'Posts, stories, anúncios e materiais digitais.' },
    { id: 's2', icon: 'flyer', title: 'Flyers e Materiais Promocionais', desc: 'Artes para empresas, eventos, igrejas, promoções e campanhas.' },
    { id: 's3', icon: 'sign', title: 'Fachadas e Placas', desc: 'Desenvolvimento e preparação das artes para produção.' },
    { id: 's4', icon: 'car', title: 'Plotagem de Veículos', desc: 'Criação e preparação de layouts para carros, motos, vans e veículos comerciais.' },
    { id: 's5', icon: 'banner', title: 'Banners e Comunicação Visual', desc: 'Criação de materiais para impressão em pequenos e grandes formatos.' },
    { id: 's6', icon: 'logo', title: 'Logotipos e Identidade Visual', desc: 'Criação de marcas e elementos de identidade visual.' },
    { id: 's7', icon: 'file', title: 'Arte-Final', desc: 'Preparação e fechamento profissional de arquivos para impressão e produção gráfica.' }
  ];

  var DEFAULT_CONFIG = {
    heroTitle: 'Transformando ideias em comunicação visual.',
    heroSubtitle: 'Design Gráfico • Arte-Final • Comunicação Visual',
    heroDesc: 'Criação de artes profissionais desenvolvidas para destacar empresas, marcas, eventos e projetos.',
    aboutBio: 'Olá! Sou Anderson Wesley, Designer Gráfico e Arte-Finalista de Caldas Novas – GO.\n\nTrabalho com criação de materiais gráficos e desenvolvimento de artes para comunicação visual, ajudando empresas, profissionais e projetos a transformarem suas ideias em materiais visuais profissionais.\n\nTenho experiência na criação de artes para redes sociais, flyers, banners, fachadas, placas, adesivos, plotagem de veículos e diversos materiais para impressão.',
    phone: '(64) 99235-5772',
    whatsapp: WHATSAPP_NUMBER,
    logo: LOGO_DEFAULT,
    photo: PHOTO_DEFAULT,
    services: DEFAULT_SERVICES
  };

  /* ---------- IndexedDB ---------- */
  var _db = null;
  function openDB() {
    return new Promise(function (resolve, reject) {
      if (_db) return resolve(_db);
      var req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = function (e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains('projects')) {
          var ps = db.createObjectStore('projects', { keyPath: 'id' });
          ps.createIndex('order', 'order');
        }
        if (!db.objectStoreNames.contains('messages')) {
          db.createObjectStore('messages', { keyPath: 'id' });
        }
      };
      req.onsuccess = function (e) { _db = e.target.result; resolve(_db); };
      req.onerror = function (e) { reject(e.target.error); };
    });
  }

  function tx(store, mode) {
    return openDB().then(function (db) {
      return db.transaction(store, mode).objectStore(store);
    });
  }
  function reqToPromise(request) {
    return new Promise(function (res, rej) {
      request.onsuccess = function () { res(request.result); };
      request.onerror = function () { rej(request.error); };
    });
  }

  /* ---------- Config (localStorage) ---------- */
  function getConfig() {
    try {
      var c = JSON.parse(localStorage.getItem(LS_CONFIG) || 'null');
      if (!c) return Object.assign({}, DEFAULT_CONFIG);
      // garante serviços presentes
      if (!c.services || !c.services.length) c.services = DEFAULT_SERVICES;
      return Object.assign({}, DEFAULT_CONFIG, c);
    } catch (e) { return Object.assign({}, DEFAULT_CONFIG); }
  }
  function saveConfig(cfg) {
    localStorage.setItem(LS_CONFIG, JSON.stringify(cfg));
    return cfg;
  }

  /* ---------- Projetos ---------- */
  function getProjects() {
    return tx('projects', 'readonly').then(function (store) {
      return reqToPromise(store.getAll());
    }).then(function (list) {
      list.sort(function (a, b) { return (a.order || 0) - (b.order || 0); });
      return list;
    });
  }
  function saveProject(p) {
    if (!p.id) p.id = 'p_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
    if (p.order == null) p.order = Date.now();
    if (!p.createdAt) p.createdAt = Date.now();
    return tx('projects', 'readwrite').then(function (store) {
      return reqToPromise(store.put(p));
    }).then(function () { return p; });
  }
  function deleteProject(id) {
    return tx('projects', 'readwrite').then(function (store) {
      return reqToPromise(store.delete(id));
    });
  }
  function reorderProjects(idsInOrder) {
    return getProjects().then(function (list) {
      var map = {};
      list.forEach(function (p) { map[p.id] = p; });
      var ops = idsInOrder.map(function (id, i) {
        if (map[id]) { map[id].order = i; return saveProject(map[id]); }
        return Promise.resolve();
      });
      return Promise.all(ops);
    });
  }

  /* ---------- Mensagens / Orçamentos ---------- */
  function getMessages() {
    return tx('messages', 'readonly').then(function (store) {
      return reqToPromise(store.getAll());
    }).then(function (list) {
      list.sort(function (a, b) { return b.createdAt - a.createdAt; });
      return list;
    });
  }
  function saveMessage(m) {
    m.id = 'm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    m.createdAt = Date.now();
    m.read = false;
    return tx('messages', 'readwrite').then(function (store) {
      return reqToPromise(store.put(m));
    }).then(function () { return m; });
  }
  function saveMessage2(m) {
    // grava sem alterar id/estado (usado para marcar como lido e importar backup)
    if (!m.id) m.id = 'm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6);
    if (!m.createdAt) m.createdAt = Date.now();
    return tx('messages', 'readwrite').then(function (store) {
      return reqToPromise(store.put(m));
    }).then(function () { return m; });
  }
  function deleteMessage(id) {
    return tx('messages', 'readwrite').then(function (store) {
      return reqToPromise(store.delete(id));
    });
  }

  /* ---------- Autenticação (hash local, sem senha em código) ---------- */
  function sha256(str) {
    var enc = new TextEncoder();
    return crypto.subtle.digest('SHA-256', enc.encode(str)).then(function (buf) {
      return Array.from(new Uint8Array(buf)).map(function (b) {
        return b.toString(16).padStart(2, '0');
      }).join('');
    });
  }
  function isSetup() { return !!localStorage.getItem(LS_AUTH); }
  function setupAuth(user, pass) {
    return sha256(pass).then(function (h) {
      localStorage.setItem(LS_AUTH, JSON.stringify({ user: user, hash: h }));
      return true;
    });
  }
  function login(user, pass) {
    var stored = JSON.parse(localStorage.getItem(LS_AUTH) || 'null');
    if (!stored) return Promise.resolve(false);
    return sha256(pass).then(function (h) {
      if (stored.user === user && stored.hash === h) {
        sessionStorage.setItem(LS_SESSION, '1');
        localStorage.setItem(LS_SESSION, String(Date.now()));
        return true;
      }
      return false;
    });
  }
  function isLogged() { return sessionStorage.getItem(LS_SESSION) === '1'; }
  function logout() { sessionStorage.removeItem(LS_SESSION); }
  function changePassword(pass) {
    var stored = JSON.parse(localStorage.getItem(LS_AUTH) || 'null') || { user: 'admin' };
    return sha256(pass).then(function (h) {
      stored.hash = h;
      localStorage.setItem(LS_AUTH, JSON.stringify(stored));
      return true;
    });
  }

  function waLink(text) {
    var cfg = getConfig();
    var num = (cfg.whatsapp || WHATSAPP_NUMBER).replace(/\D/g, '');
    var base = 'https://wa.me/' + num;
    return text ? base + '?text=' + encodeURIComponent(text) : base;
  }

  global.Store = {
    CATEGORIES: CATEGORIES,
    PHOTO_DEFAULT: PHOTO_DEFAULT,
    LOGO_DEFAULT: LOGO_DEFAULT,
    placeholderImg: svg,
    getConfig: getConfig, saveConfig: saveConfig,
    getProjects: getProjects, saveProject: saveProject, deleteProject: deleteProject, reorderProjects: reorderProjects,
    getMessages: getMessages, saveMessage: saveMessage, saveMessage2: saveMessage2, deleteMessage: deleteMessage,
    isSetup: isSetup, setupAuth: setupAuth, login: login, isLogged: isLogged, logout: logout, changePassword: changePassword,
    waLink: waLink
  };
})(window);
