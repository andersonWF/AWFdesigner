/* ============================================================
   AWF Visual Studio - Painel Administrativo
   ============================================================ */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function flash(el) { if (!el) return; el.classList.add('show'); setTimeout(function () { el.classList.remove('show'); }, 2200); }

  /* Redimensiona/otimiza imagem para base64 (economia de espaço e desempenho) */
  function fileToOptimized(file, maxW) {
    maxW = maxW || 1400;
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onload = function (e) {
        var img = new Image();
        img.onload = function () {
          var scale = Math.min(1, maxW / img.width);
          var w = Math.round(img.width * scale), h = Math.round(img.height * scale);
          var canvas = document.createElement('canvas');
          canvas.width = w; canvas.height = h;
          canvas.getContext('2d').drawImage(img, 0, 0, w, h);
          var out = canvas.toDataURL('image/jpeg', 0.85);
          resolve(out);
        };
        img.onerror = reject;
        img.src = e.target.result;
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }

  /* ============ AUTENTICAÇÃO ============ */
  function showAuth() {
    $('#authScreen').hidden = false;
    $('#adminApp').hidden = true;
    if (Store.isSetup()) { $('#loginForm').hidden = false; $('#setupForm').hidden = true; }
    else { $('#setupForm').hidden = false; $('#loginForm').hidden = true; }
  }
  function showApp() {
    $('#authScreen').hidden = true;
    $('#adminApp').hidden = false;
    var auth = JSON.parse(localStorage.getItem('awf_auth') || '{}');
    $('#adminUser').textContent = auth.user ? '👤 ' + auth.user : '';
    initApp();
  }

  function initAuth() {
    $('#setupForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var u = $('#setUser').value.trim(), p = $('#setPass').value, p2 = $('#setPass2').value;
      var msg = $('#setupMsg'); msg.className = 'auth-msg';
      if (p.length < 6) { msg.textContent = 'A senha deve ter ao menos 6 caracteres.'; return; }
      if (p !== p2) { msg.textContent = 'As senhas não coincidem.'; return; }
      Store.setupAuth(u, p).then(function () {
        return Store.login(u, p);
      }).then(function () { showApp(); });
    });
    $('#loginForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var u = $('#logUser').value.trim(), p = $('#logPass').value;
      var msg = $('#loginMsg'); msg.className = 'auth-msg';
      Store.login(u, p).then(function (ok) {
        if (ok) showApp();
        else { msg.textContent = 'Usuário ou senha incorretos.'; }
      });
    });
  }

  /* ============ NAVEGAÇÃO ============ */
  var TITLES = { dashboard: 'Dashboard', projects: 'Portfólio', messages: 'Orçamentos', services: 'Serviços', content: 'Conteúdo & Identidade', account: 'Minha Conta' };
  function switchView(v) {
    $$('.view').forEach(function (el) { el.hidden = true; });
    var view = $('#view-' + v); if (view) view.hidden = false;
    $$('.admin-link').forEach(function (l) { l.classList.toggle('active', l.getAttribute('data-view') === v); });
    $('#viewTitle').textContent = TITLES[v] || v;
    closeSidebar();
    if (v === 'dashboard') renderDashboard();
    if (v === 'projects') renderProjectsAdmin();
    if (v === 'messages') renderMessages();
    if (v === 'services') renderServicesAdmin();
    if (v === 'content') loadContentForm();
  }
  function openSidebar() { $('#sidebar').classList.add('open'); $('#backdrop').classList.add('show'); }
  function closeSidebar() { $('#sidebar').classList.remove('open'); var b = $('#backdrop'); if (b) b.classList.remove('show'); }

  /* ============ DASHBOARD ============ */
  function renderDashboard() {
    Promise.all([Store.getProjects(), Store.getMessages()]).then(function (r) {
      var projects = r[0], msgs = r[1];
      $('#stTotal').textContent = projects.length;
      $('#stMsgs').textContent = msgs.length;
      $('#stNew').textContent = msgs.filter(function (m) { return !m.read; }).length;
      var counts = {};
      projects.forEach(function (p) { counts[p.category] = (counts[p.category] || 0) + 1; });
      $('#stCats').textContent = Object.keys(counts).length;
      var max = Math.max.apply(null, [1].concat(Object.values(counts)));
      $('#catChart').innerHTML = Store.CATEGORIES.map(function (c) {
        var n = counts[c] || 0;
        return '<div class="cat-bar"><span class="lbl">' + esc(c) + '</span>' +
          '<span class="track"><span class="fill" style="width:' + (n / max * 100) + '%"></span></span>' +
          '<span class="val">' + n + '</span></div>';
      }).join('');
      var recent = projects.slice().sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); }).slice(0, 5);
      $('#recentProjects').innerHTML = recent.length ? recent.map(function (p) {
        return '<li><img src="' + p.image + '" alt=""><div class="info"><strong>' + esc(p.title) + '</strong><span>' + esc(p.category) + '</span></div></li>';
      }).join('') : '<li style="color:#8a8a8a">Nenhum projeto ainda.</li>';
    });
  }

  /* ============ PROJETOS ============ */
  function renderProjectsAdmin() {
    Store.getProjects().then(function (list) {
      var grid = $('#projectsAdminGrid');
      if (!list.length) { grid.innerHTML = '<p style="color:#8a8a8a">Nenhum projeto. Clique em “Novo Projeto” para começar.</p>'; return; }
      grid.innerHTML = list.map(function (p) {
        return '<div class="pa-card" draggable="true" data-id="' + p.id + '">' +
          '<img src="' + p.image + '" alt="' + esc(p.title) + '">' +
          '<div class="pa-body"><span class="cat">' + esc(p.category) + '</span>' +
          '<h4>' + esc(p.title) + '</h4><p>' + esc(p.desc || '') + '</p></div>' +
          '<div class="pa-actions"><button class="edit" data-id="' + p.id + '">Editar</button>' +
          '<button class="del" data-id="' + p.id + '">Excluir</button></div></div>';
      }).join('');
      bindProjectCards();
      enableDragReorder(grid);
    });
  }
  function bindProjectCards() {
    $$('.pa-actions .edit').forEach(function (b) {
      b.addEventListener('click', function () { openProjectModal(b.getAttribute('data-id')); });
    });
    $$('.pa-actions .del').forEach(function (b) {
      b.addEventListener('click', function () {
        if (confirm('Excluir este projeto? Esta ação não pode ser desfeita.')) {
          Store.deleteProject(b.getAttribute('data-id')).then(renderProjectsAdmin);
        }
      });
    });
  }
  function enableDragReorder(grid) {
    var dragging = null;
    $$('.pa-card', grid).forEach(function (card) {
      card.addEventListener('dragstart', function () { dragging = card; card.classList.add('dragging'); });
      card.addEventListener('dragend', function () {
        card.classList.remove('dragging'); dragging = null;
        var ids = $$('.pa-card', grid).map(function (c) { return c.getAttribute('data-id'); });
        Store.reorderProjects(ids);
      });
    });
    grid.addEventListener('dragover', function (e) {
      e.preventDefault();
      if (!dragging) return;
      var after = getDragAfter(grid, e.clientY, e.clientX);
      if (after == null) grid.appendChild(dragging);
      else grid.insertBefore(dragging, after);
    });
  }
  function getDragAfter(grid, y, x) {
    var cards = $$('.pa-card:not(.dragging)', grid);
    var closest = { dist: -Infinity, el: null };
    cards.forEach(function (c) {
      var box = c.getBoundingClientRect();
      var offset = y - box.top - box.height / 2;
      if (offset < 0 && offset > closest.dist) closest = { dist: offset, el: c };
    });
    return closest.el;
  }

  /* ---- Modal projeto ---- */
  var pendingImage = null;
  function openProjectModal(id) {
    pendingImage = null;
    var sel = $('#pCategory');
    sel.innerHTML = Store.CATEGORIES.map(function (c) { return '<option>' + esc(c) + '</option>'; }).join('');
    if (id) {
      Store.getProjects().then(function (list) {
        var p = list.filter(function (x) { return x.id === id; })[0];
        if (!p) return;
        $('#modalTitle').textContent = 'Editar Projeto';
        $('#pId').value = p.id;
        $('#pName').value = p.title;
        $('#pCategory').value = p.category;
        $('#pDesc').value = p.desc || '';
        showPreview(p.image);
        pendingImage = p.image;
        openModal();
      });
    } else {
      $('#modalTitle').textContent = 'Novo Projeto';
      $('#projectForm').reset();
      $('#pId').value = '';
      showPreview(null);
      openModal();
    }
  }
  function showPreview(src) {
    var img = $('#pPreview'), ph = $('#uploadPlaceholder');
    if (src) { img.src = src; img.hidden = false; ph.hidden = true; }
    else { img.hidden = true; ph.hidden = false; }
  }
  function openModal() { $('#projectModal').hidden = false; document.body.style.overflow = 'hidden'; }
  function closeModal() { $('#projectModal').hidden = true; document.body.style.overflow = ''; }

  function initProjectModal() {
    $('#newProjectBtn').addEventListener('click', function () { openProjectModal(null); });
    $('#modalClose').addEventListener('click', closeModal);
    $('#modalCancel').addEventListener('click', closeModal);
    $('#projectModal').addEventListener('click', function (e) { if (e.target.id === 'projectModal') closeModal(); });

    var area = $('#uploadArea'), input = $('#pImage');
    input.addEventListener('change', function () {
      if (input.files[0]) fileToOptimized(input.files[0]).then(function (d) { pendingImage = d; showPreview(d); });
    });
    ['dragenter', 'dragover'].forEach(function (ev) { area.addEventListener(ev, function (e) { e.preventDefault(); area.classList.add('drag'); }); });
    ['dragleave', 'drop'].forEach(function (ev) { area.addEventListener(ev, function (e) { e.preventDefault(); area.classList.remove('drag'); }); });
    area.addEventListener('drop', function (e) {
      var f = e.dataTransfer.files[0];
      if (f && f.type.indexOf('image') === 0) fileToOptimized(f).then(function (d) { pendingImage = d; showPreview(d); });
    });

    $('#projectForm').addEventListener('submit', function (e) {
      e.preventDefault();
      if (!pendingImage) { alert('Selecione uma imagem para o projeto.'); return; }
      var proj = {
        id: $('#pId').value || null,
        title: $('#pName').value.trim(),
        category: $('#pCategory').value,
        desc: $('#pDesc').value.trim(),
        image: pendingImage
      };
      Store.saveProject(proj).then(function () { closeModal(); renderProjectsAdmin(); });
    });
  }

  /* ============ MENSAGENS ============ */
  function renderMessages() {
    Store.getMessages().then(function (list) {
      var wrap = $('#msgsList');
      if (!list.length) { wrap.innerHTML = '<p style="color:#8a8a8a">Nenhuma solicitação de orçamento recebida ainda.</p>'; return; }
      wrap.innerHTML = list.map(function (m) {
        var d = new Date(m.createdAt);
        var wa = 'https://wa.me/' + (m.whatsapp || '').replace(/\D/g, '');
        return '<div class="msg-card' + (m.read ? '' : ' unread') + '">' +
          '<div class="msg-top"><strong>' + esc(m.nome) + '</strong>' + (m.read ? '' : '<span class="badge">Novo</span>') + '</div>' +
          '<div class="msg-meta">' + d.toLocaleString('pt-BR') + ' &bull; <a href="' + wa + '" target="_blank" rel="noopener">' + esc(m.whatsapp) + '</a></div>' +
          '<span class="msg-service">' + esc(m.servico) + '</span>' +
          '<p class="body">' + esc(m.descricao) + '</p>' +
          '<div class="msg-card-actions">' +
          '<a class="btn btn-whats" href="' + wa + '" target="_blank" rel="noopener">Responder</a>' +
          (m.read ? '' : '<button class="btn btn-outline mark" data-id="' + m.id + '">Marcar como lido</button>') +
          '<button class="btn btn-outline delmsg" data-id="' + m.id + '">Excluir</button>' +
          '</div></div>';
      }).join('');
      $$('.mark').forEach(function (b) {
        b.addEventListener('click', function () {
          var id = b.getAttribute('data-id');
          Store.getMessages().then(function (all) {
            var m = all.filter(function (x) { return x.id === id; })[0];
            if (m) { m.read = true; Store.saveMessage2(m); }
          });
        });
      });
      $$('.delmsg').forEach(function (b) {
        b.addEventListener('click', function () {
          if (confirm('Excluir esta solicitação?')) Store.deleteMessage(b.getAttribute('data-id')).then(renderMessages);
        });
      });
    });
  }

  /* ============ SERVIÇOS ============ */
  function renderServicesAdmin() {
    var cfg = Store.getConfig();
    var wrap = $('#servicesAdmin');
    wrap.innerHTML = cfg.services.map(function (s, i) {
      return '<div class="svc-admin-card" data-i="' + i + '">' +
        '<label>Título</label><input class="svc-title" value="' + esc(s.title) + '">' +
        '<label>Descrição</label><textarea class="svc-desc" rows="2">' + esc(s.desc) + '</textarea></div>';
    }).join('') + '<button class="btn btn-primary" id="saveSvc">Salvar serviços</button><span class="save-flash" id="svcFlash">Salvo!</span>';
    $('#saveSvc').addEventListener('click', function () {
      var cfg = Store.getConfig();
      $$('.svc-admin-card').forEach(function (card, i) {
        cfg.services[i].title = $('.svc-title', card).value.trim();
        cfg.services[i].desc = $('.svc-desc', card).value.trim();
      });
      Store.saveConfig(cfg); flash($('#svcFlash'));
    });
  }

  /* ============ CONTEÚDO / IDENTIDADE ============ */
  var newLogo = null, newPhoto = null;
  function loadContentForm() {
    var cfg = Store.getConfig();
    newLogo = null; newPhoto = null;
    $('#cHeroTitle').value = cfg.heroTitle;
    $('#cHeroSubtitle').value = cfg.heroSubtitle;
    $('#cHeroDesc').value = cfg.heroDesc;
    $('#cBio').value = cfg.aboutBio;
    $('#cPhone').value = cfg.phone;
    $('#cWhats').value = cfg.whatsapp;
    $('#prevLogo').src = cfg.logo;
    $('#prevPhoto').src = cfg.photo;
  }
  function initContentForm() {
    $('#fileLogo').addEventListener('change', function (e) {
      if (e.target.files[0]) fileToOptimized(e.target.files[0], 300).then(function (d) { newLogo = d; $('#prevLogo').src = d; });
    });
    $('#filePhoto').addEventListener('change', function (e) {
      if (e.target.files[0]) fileToOptimized(e.target.files[0], 900).then(function (d) { newPhoto = d; $('#prevPhoto').src = d; });
    });
    $('#contentForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var cfg = Store.getConfig();
      cfg.heroTitle = $('#cHeroTitle').value.trim();
      cfg.heroSubtitle = $('#cHeroSubtitle').value.trim();
      cfg.heroDesc = $('#cHeroDesc').value.trim();
      cfg.aboutBio = $('#cBio').value;
      cfg.phone = $('#cPhone').value.trim();
      cfg.whatsapp = $('#cWhats').value.replace(/\D/g, '');
      if (newLogo) cfg.logo = newLogo;
      if (newPhoto) cfg.photo = newPhoto;
      Store.saveConfig(cfg); flash($('#contentFlash'));
    });
  }

  /* ============ CONTA & BACKUP ============ */
  function initAccount() {
    $('#accountForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var p = $('#newPass').value, p2 = $('#newPass2').value;
      if (p.length < 6) { alert('A senha deve ter ao menos 6 caracteres.'); return; }
      if (p !== p2) { alert('As senhas não coincidem.'); return; }
      Store.changePassword(p).then(function () { $('#accountForm').reset(); flash($('#accountFlash')); });
    });
    $('#exportBtn').addEventListener('click', function () {
      Promise.all([Store.getProjects(), Store.getMessages()]).then(function (r) {
        var data = { config: Store.getConfig(), projects: r[0], messages: r[1], exportedAt: new Date().toISOString() };
        var blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'awf-backup-' + new Date().toISOString().slice(0, 10) + '.json';
        a.click();
        flash($('#backupFlash'));
      });
    });
    $('#importFile').addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      var reader = new FileReader();
      reader.onload = function (ev) {
        try {
          var data = JSON.parse(ev.target.result);
          if (data.config) Store.saveConfig(data.config);
          var ops = (data.projects || []).map(function (p) { return Store.saveProject(p); })
            .concat((data.messages || []).map(function (m) { return Store.saveMessage2(m); }));
          Promise.all(ops).then(function () { alert('Backup importado com sucesso!'); flash($('#backupFlash')); });
        } catch (err) { alert('Arquivo de backup inválido.'); }
      };
      reader.readAsText(f);
    });
  }

  /* ============ INIT APP ============ */
  var appInited = false;
  function initApp() {
    if (appInited) { renderDashboard(); return; }
    appInited = true;
    // backdrop dyn
    var bd = document.createElement('div');
    bd.className = 'sidebar-backdrop'; bd.id = 'backdrop';
    document.body.appendChild(bd);
    bd.addEventListener('click', closeSidebar);
    $('#adminBurger').addEventListener('click', openSidebar);
    $$('.admin-link').forEach(function (l) {
      l.addEventListener('click', function () { switchView(l.getAttribute('data-view')); });
    });
    $('#logoutBtn').addEventListener('click', function () { Store.logout(); location.reload(); });
    initProjectModal();
    initContentForm();
    initAccount();
    switchView('dashboard');
  }

  document.addEventListener('DOMContentLoaded', function () {
    initAuth();
    if (Store.isLogged()) showApp(); else showAuth();
  });
})();
