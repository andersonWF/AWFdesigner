/* ============================================================
   AWF Visual Studio - Front-end público
   ============================================================ */
(function () {
  'use strict';
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  /* ---- Ícones dos serviços ---- */
  var ICONS = {
    social: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1.2" fill="currentColor"/></svg>',
    flyer: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="5" y="3" width="14" height="18" rx="2"/><line x1="8" y1="8" x2="16" y2="8"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="13" y2="16"/></svg>',
    sign: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="5" width="18" height="10" rx="2"/><line x1="12" y1="15" x2="12" y2="21"/><line x1="9" y1="21" x2="15" y2="21"/></svg>',
    car: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 13l2-5a2 2 0 0 1 2-1.3h10A2 2 0 0 1 19 8l2 5v5h-3v-2H6v2H3z"/><circle cx="7.5" cy="16" r="1.5"/><circle cx="16.5" cy="16" r="1.5"/></svg>',
    banner: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="6" width="18" height="9" rx="1"/><line x1="7" y1="15" x2="7" y2="20"/><line x1="17" y1="15" x2="17" y2="20"/></svg>',
    logo: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="9"/><path d="M8 14l2.5-5 2 3 1.5-2 2 4"/></svg>',
    file: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/><path d="M9 13l2 2 4-4"/></svg>'
  };

  var cfg = Store.getConfig();
  var allProjects = [];
  var currentList = [];
  var currentIndex = 0;

  function escapeHtml(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  /* ---- Aplica configurações ---- */
  function applyConfig() {
    $('#navLogo').src = cfg.logo;
    $('#heroPhoto').src = cfg.photo;
    $('#aboutPhoto').src = cfg.photo;
    $('#heroTitle').textContent = cfg.heroTitle;
    $('#heroSubtitle').innerHTML = escapeHtml(cfg.heroSubtitle);
    $('#heroDesc').textContent = cfg.heroDesc;
    $('#contatoPhone').textContent = cfg.phone;
    // bio (parágrafos)
    var bio = $('#aboutBio');
    bio.innerHTML = '';
    cfg.aboutBio.split(/\n\n+/).forEach(function (par) {
      if (par.trim()) { var p = document.createElement('p'); p.textContent = par.trim(); bio.appendChild(p); }
    });
    // links whatsapp
    var wa = Store.waLink('Olá! Vim pelo site da AWF Visual Studio e gostaria de mais informações.');
    ['heroWhats', 'contatoWhats', 'whatsFloat'].forEach(function (id) {
      var el = document.getElementById(id); if (el) { el.href = wa; el.target = '_blank'; el.rel = 'noopener'; }
    });
  }

  /* ---- Serviços ---- */
  function renderServices() {
    var grid = $('#servicesGrid');
    grid.innerHTML = cfg.services.map(function (s) {
      return '<article class="service-card reveal">' +
        '<div class="service-icon">' + (ICONS[s.icon] || ICONS.file) + '</div>' +
        '<h3>' + escapeHtml(s.title) + '</h3>' +
        '<p>' + escapeHtml(s.desc) + '</p></article>';
    }).join('');
  }

  /* ---- Portfólio ---- */
  function renderFilters() {
    var cats = ['Todos'].concat(Store.CATEGORIES);
    $('#portfolioFilters').innerHTML = cats.map(function (c, i) {
      return '<button class="filter-btn' + (i === 0 ? ' active' : '') + '" data-cat="' + escapeHtml(c) + '">' + escapeHtml(c) + '</button>';
    }).join('');
    $$('#portfolioFilters .filter-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        $$('#portfolioFilters .filter-btn').forEach(function (b) { b.classList.remove('active'); });
        btn.classList.add('active');
        renderPortfolio(btn.getAttribute('data-cat'));
      });
    });
  }

  function renderPortfolio(cat) {
    cat = cat || 'Todos';
    currentList = (cat === 'Todos') ? allProjects : allProjects.filter(function (p) { return p.category === cat; });
    var grid = $('#portfolioGrid');
    $('#portfolioEmpty').hidden = currentList.length > 0;
    grid.innerHTML = currentList.map(function (p, i) {
      return '<div class="pf-item reveal" data-i="' + i + '">' +
        '<img src="' + p.image + '" alt="' + escapeHtml(p.title) + '" loading="lazy">' +
        '<div class="pf-overlay"><span class="cat">' + escapeHtml(p.category) + '</span>' +
        '<h3>' + escapeHtml(p.title) + '</h3>' +
        '<p>' + escapeHtml(p.desc || '') + '</p></div></div>';
    }).join('');
    $$('#portfolioGrid .pf-item').forEach(function (item) {
      item.addEventListener('click', function () { openLightbox(parseInt(item.getAttribute('data-i'), 10)); });
    });
    observeReveals();
  }

  /* ---- Lightbox ---- */
  function openLightbox(i) {
    currentIndex = i;
    var p = currentList[i]; if (!p) return;
    $('#lightboxImg').src = p.image;
    $('#lightboxImg').alt = p.title;
    $('#lightboxCat').textContent = p.category;
    $('#lightboxTitle').textContent = p.title;
    $('#lightboxDesc').textContent = p.desc || '';
    $('#lightbox').hidden = false;
    document.body.style.overflow = 'hidden';
  }
  function closeLightbox() { $('#lightbox').hidden = true; document.body.style.overflow = ''; }
  function nav(d) { var n = currentList.length; if (!n) return; currentIndex = (currentIndex + d + n) % n; openLightbox(currentIndex); }

  /* ---- Formulário de contato ---- */
  function initForm() {
    $('#contatoForm').addEventListener('submit', function (e) {
      e.preventDefault();
      var data = {
        nome: $('#fNome').value.trim(),
        whatsapp: $('#fWhats').value.trim(),
        servico: $('#fServico').value,
        descricao: $('#fDesc').value.trim()
      };
      Store.saveMessage(data).then(function () {
        var msg = $('#formMsg');
        msg.hidden = false;
        msg.textContent = 'Solicitação enviada! Vou abrir o WhatsApp para agilizar o seu atendimento.';
        e.target.reset();
        var txt = 'Olá! Sou ' + data.nome + '. Gostaria de um orçamento de "' + data.servico + '". Detalhes: ' + data.descricao;
        setTimeout(function () { window.open(Store.waLink(txt), '_blank', 'noopener'); }, 700);
      });
    });
  }

  /* ---- Reveal on scroll ---- */
  var io;
  function observeReveals() {
    if (!io) {
      io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) { if (en.isIntersecting) { en.target.classList.add('visible'); io.unobserve(en.target); } });
      }, { threshold: 0.12 });
    }
    $$('.reveal:not(.visible)').forEach(function (el) { io.observe(el); });
  }

  /* ---- Header + Menu mobile ---- */
  function initNav() {
    var header = $('#header');
    window.addEventListener('scroll', function () {
      header.classList.toggle('scrolled', window.scrollY > 40);
    });
    var toggle = $('#navToggle'), nav = $('#mainNav');
    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('open');
      toggle.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', String(open));
    });
    $$('#mainNav a').forEach(function (a) {
      a.addEventListener('click', function () { nav.classList.remove('open'); toggle.classList.remove('open'); });
    });
  }

  function initLightbox() {
    $('#lightboxClose').addEventListener('click', closeLightbox);
    $('#lightboxPrev').addEventListener('click', function () { nav(-1); });
    $('#lightboxNext').addEventListener('click', function () { nav(1); });
    $('#lightbox').addEventListener('click', function (e) { if (e.target.id === 'lightbox') closeLightbox(); });
    document.addEventListener('keydown', function (e) {
      if ($('#lightbox').hidden) return;
      if (e.key === 'Escape') closeLightbox();
      if (e.key === 'ArrowLeft') nav(-1);
      if (e.key === 'ArrowRight') nav(1);
    });
  }

  /* ---- Init ---- */
  document.addEventListener('DOMContentLoaded', function () {
    $('#year').textContent = new Date().getFullYear();
    applyConfig();
    renderServices();
    renderFilters();
    initForm();
    initNav();
    initLightbox();
    Store.getProjects().then(function (list) {
      allProjects = list;
      $('#statProjetos').textContent = list.length;
      renderPortfolio('Todos');
      observeReveals();
    });
    observeReveals();
  });
})();
